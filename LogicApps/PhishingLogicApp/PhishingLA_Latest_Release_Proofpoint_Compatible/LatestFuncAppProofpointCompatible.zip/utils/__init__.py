# In utils/__init__.py
from utils import url_processor