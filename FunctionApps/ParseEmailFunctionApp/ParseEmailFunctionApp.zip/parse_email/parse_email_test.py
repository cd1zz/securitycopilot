import email
from email import policy
from email.parser import BytesParser
import sys
from pathlib import Path
import logging
from typing import Optional, Dict, Any, List
from bs4 import BeautifulSoup
import re

class EmailContentExtractor:
    def __init__(self, email_path: str):
        """Initialize the email content extractor.
        
        Args:
            email_path (str): Path to the email file to parse
        """
        self.email_path = Path(email_path)
        self._setup_logging()

    def _setup_logging(self) -> None:
        """Configure logging."""
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )
        self.logger = logging.getLogger(__name__)

    def _read_email_file(self) -> Optional[bytes]:
        """Read the email file safely."""
        try:
            with open(self.email_path, 'rb') as f:
                return f.read()
        except (IOError, OSError) as e:
            self.logger.error(f"Failed to read email file: {e}")
            return None

    def _parse_email(self, email_content: bytes) -> Optional[email.message.EmailMessage]:
        """Parse email content into an EmailMessage object."""
        try:
            return BytesParser(policy=policy.default).parsebytes(email_content)
        except Exception as e:
            self.logger.error(f"Failed to parse email content: {e}")
            return None

    def _parse_addresses(self, address_field: str) -> List[str]:
        """Parse email addresses from a header field."""
        addresses = []
        # Split on commas, handling potential nested commas in quotes
        parts = re.findall(r'(?:[^,"]|"(?:\\.|[^"])*")+', address_field)
        for part in parts:
            # Clean up the address
            clean_addr = part.strip(' "\'<>')
            if clean_addr:
                addresses.append(clean_addr)
        return addresses

    def _extract_html_content(self, html_content: str) -> str:
        """Extract readable text from HTML content."""
        try:
            soup = BeautifulSoup(html_content, 'html.parser')
            
            # Remove script and style elements
            for element in soup(['script', 'style']):
                element.decompose()
            
            # Get text and clean it up
            text = soup.get_text(separator='\n', strip=True)
            # Remove excessive newlines
            text = re.sub(r'\n\s*\n', '\n\n', text)
            return text.strip()
        except Exception as e:
            self.logger.error(f"Error parsing HTML: {e}")
            return html_content

    def _process_message(self, message: email.message.EmailMessage) -> Dict[str, Any]:
        """Process a message (either main or attached) and extract content."""
        result = {
            'from': message.get('From', ''),
            'to': self._parse_addresses(message.get('To', '')),
            'cc': self._parse_addresses(message.get('Cc', '')),
            'subject': message.get('Subject', ''),
            'date': message.get('Date', ''),
            'body': '',
            'attachments': []
        }

        if message.is_multipart():
            # Handle multipart messages
            for part in message.walk():
                if part.get_content_maintype() == 'multipart':
                    continue
                
                filename = part.get_filename()
                content_type = part.get_content_type()
                
                if filename:
                    # This is an attachment
                    result['attachments'].append({
                        'filename': filename,
                        'content_type': content_type,
                        'size': len(part.get_payload(decode=True))
                    })
                elif content_type == 'text/plain':
                    # Add plain text to body
                    payload = part.get_payload(decode=True).decode(part.get_content_charset() or 'utf-8', 'replace')
                    if result['body']:
                        result['body'] += '\n\n' + payload
                    else:
                        result['body'] = payload
                elif content_type == 'text/html':
                    # Extract text from HTML
                    html_content = part.get_payload(decode=True).decode(part.get_content_charset() or 'utf-8', 'replace')
                    extracted_text = self._extract_html_content(html_content)
                    if not result['body']:  # Only use HTML if we don't have plain text
                        result['body'] = extracted_text
        else:
            # Handle non-multipart messages
            content_type = message.get_content_type()
            if content_type == 'text/plain':
                result['body'] = message.get_payload(decode=True).decode(message.get_content_charset() or 'utf-8', 'replace')
            elif content_type == 'text/html':
                html_content = message.get_payload(decode=True).decode(message.get_content_charset() or 'utf-8', 'replace')
                result['body'] = self._extract_html_content(html_content)

        return result

    def extract_content(self) -> List[Dict[str, Any]]:
        """Extract content from the email and any attached emails.
        
        Returns:
            List of dictionaries containing email content. First item is the main email,
            followed by any attached emails.
        """
        email_content = self._read_email_file()
        if not email_content:
            return []

        email_message = self._parse_email(email_content)
        if not email_message:
            return []

        try:
            results = []
            # Process the main email
            main_content = self._process_message(email_message)
            results.append(main_content)

            # Look for attached emails
            if email_message.is_multipart():
                for part in email_message.walk():
                    if part.get_content_type() == 'message/rfc822':
                        attached_msg = part.get_payload()[0]
                        attached_content = self._process_message(attached_msg)
                        results.append(attached_content)

            return results

        except Exception as e:
            self.logger.error(f"Error extracting content: {e}")
            import traceback
            self.logger.error(traceback.format_exc())
            return []

    def print_extracted_content(self) -> None:
        """Print the extracted content in a readable format."""
        contents = self.extract_content()
        if not contents:
            print("Failed to extract email content")
            return

        for i, content in enumerate(contents):
            print(f"\nEmail {i+1} of {len(contents)}")
            print("=" * 50)
            print(f"From: {content['from']}")
            print("\nTo:")
            for recipient in content['to']:
                print(f"  - {recipient}")
            if content['cc']:
                print("\nCC:")
                for recipient in content['cc']:
                    print(f"  - {recipient}")
            print(f"\nDate: {content['date']}")
            print(f"Subject: {content['subject']}")
            if content['attachments']:
                print("\nAttachments:")
                for att in content['attachments']:
                    print(f"  - {att['filename']} ({att['content_type']}, {att['size']} bytes)")
            print("\nBody:")
            print("-" * 50)
            print(content['body'])
            print("=" * 50)

def main():
    """Main entry point for the script."""
    if len(sys.argv) < 2:
        print("Usage: python script.py <path_to_email_file>")
        sys.exit(1)

    email_path = sys.argv[1]
    extractor = EmailContentExtractor(email_path)
    extractor.print_extracted_content()

if __name__ == "__main__":
    main()