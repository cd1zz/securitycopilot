import logging
import json
from utilities.email_utils import (
    extract_original_email, 
    parse_email, 
    recursive_parse
)
from utilities.entity_utils import clean_domains, dedupe_to_base_urls
from utilities.text_utils import strip_html_tags, clean_excessive_newlines
import azure.functions as func

logger = logging.getLogger(__name__)


def main(req: func.HttpRequest) -> func.HttpResponse:
    """
    Azure function main handler that processes an incoming HTTP request containing a raw email.

    Parameters:
    req (func.HttpRequest): The HTTP request object.

    Returns:
    func.HttpResponse: The HTTP response object containing parsed email data or an error message.
    """
    logger.info('Python HTTP trigger function processed a request.')

    try:
        raw_email = req.get_body()

        if isinstance(raw_email, str):
            raw_email = raw_email.encode('utf-8')

        # Step 1: Extract the original email
        try:
            original_email = extract_original_email(raw_email)
        except Exception as e:
            logger.error(f"Failed to extract original email: {e}")
            return func.HttpResponse(f"Failed to extract original email: {e}", status_code=400)

        # Step 2: Parse the extracted email
        try:
            parsed_email_data = parse_email(original_email.encode())
        except Exception as e:
            logger.error(f"Failed to parse email: {e}")
            return func.HttpResponse(f"Failed to parse email: {e}", status_code=400)

        # Step 3: Validate parsed data
        if not parsed_email_data:
            logger.error("Parsed email data is empty or invalid.")
            return func.HttpResponse("Parsed email data is empty or invalid.", status_code=400)

        try:
            # Step 4: Extract domains, IPs, and URLs
            all_domains, all_ip_addresses, all_urls = recursive_parse(parsed_email_data)

            # Clean domains to remove any leading '2f' or '40'
            all_domains = clean_domains(all_domains)

            # Convert all_urls to a list for deduplication
            url_list = list(all_urls)

            # Apply base URL deduplication if URL list length exceeds 20
            if len(url_list) > 20:
                url_list = dedupe_to_base_urls(url_list)
                logger.info(f"Deduplicated URL count: {len(url_list)}")
            else:
                logger.info("URL count is 20 or below; skipping deduplication")

            # Step 5: Construct the result
            result = {
                "sender": parsed_email_data.get("sender", ""),
                "return_path": parsed_email_data.get("return_path", ""),
                "email_to": parsed_email_data.get("email_to", ""),
                "reply_to": parsed_email_data.get("reply_to", ""),
                "subject": parsed_email_data.get("subject", ""),
                "date": parsed_email_data.get("date", ""),
                "delivered_to": parsed_email_data.get("delivered_to", ""),
                "smtp_headers": parsed_email_data.get("email_headers", []),
                "dkim_result": parsed_email_data.get("dkim_result", ""),
                "spf_result": parsed_email_data.get("spf_result", ""),
                "dmarc_result": parsed_email_data.get("dmarc_result", ""),
                "email_body": parsed_email_data.get("email_body", ""),
                "attachments": parsed_email_data.get("attachments", []),
                "ip_addresses": list(all_ip_addresses),
                "urls": url_list,
                "domains": list(all_domains),
            }

            # Step 6: Clean the email body
            result["email_body"] = strip_html_tags(result["email_body"])
            result["email_body"] = clean_excessive_newlines(result["email_body"])

            # Step 7: Return the JSON response
            json_result = json.dumps(result, indent=4)
            return func.HttpResponse(json_result, mimetype="application/json")

        except Exception as e:
            logger.error(f"Error processing parsed email data: {e}")
            return func.HttpResponse(f"Error processing parsed email data: {e}", status_code=500)

    except ValueError as e:
        logger.error(f"Value error processing request: {e}")
        return func.HttpResponse(f"Value error: {e}", status_code=400)
    except TypeError as e:
        logger.error(f"Type error processing request: {e}")
        return func.HttpResponse(f"Type error: {e}", status_code=400)
    except Exception as e:
        logger.error(f"General error processing request: {e}")
        return func.HttpResponse(f"Error: {e}", status_code=500)

def get_request_body(req: func.HttpRequest) -> bytes:
    """Extract and validate the raw email body from the HTTP request."""
    try:
        raw_email = req.get_body()
        return raw_email.encode('utf-8') if isinstance(raw_email, str) else raw_email
    except Exception as e:
        raise ValueError(f"Failed to retrieve email body: {e}")


def process_raw_email(raw_email: bytes) -> str:
    """Extract the original email content from the raw email."""
    try:
        return extract_original_email(raw_email)
    except Exception as e:
        raise ValueError(f"Failed to extract original email: {e}")


def process_parsed_email(original_email: str) -> dict:
    """Parse the original email content."""
    try:
        parsed_email_data = parse_email(original_email.encode())
        if not parsed_email_data:
            raise ValueError("Parsed email data is empty or invalid.")
        return parsed_email_data
    except Exception as e:
        raise ValueError(f"Failed to parse email: {e}")


def prepare_response(parsed_email_data: dict) -> dict:
    """Prepare the final response object."""
    try:
        all_domains, all_ip_addresses, all_urls = recursive_parse(parsed_email_data)
        all_domains = clean_domains(all_domains)

        url_list = list(all_urls)
        if len(url_list) > 20:
            url_list = dedupe_to_base_urls(url_list)

        result = {
            "sender": parsed_email_data.get("sender", ""),
            "return_path": parsed_email_data.get("return_path", ""),
            "email_to": parsed_email_data.get("email_to", ""),
            "reply_to": parsed_email_data.get("reply_to", ""),
            "subject": parsed_email_data.get("subject", ""),
            "date": parsed_email_data.get("date", ""),
            "delivered_to": parsed_email_data.get("delivered_to", ""),
            "smtp_headers": parsed_email_data.get("email_headers", []),
            "dkim_result": parsed_email_data.get("dkim_result", ""),
            "spf_result": parsed_email_data.get("spf_result", ""),
            "dmarc_result": parsed_email_data.get("dmarc_result", ""),
            "email_body": clean_excessive_newlines(
                strip_html_tags(parsed_email_data.get("email_body", ""))
            ),
            "attachments": parsed_email_data.get("attachments", []),
            "ip_addresses": list(all_ip_addresses),
            "urls": url_list,
            "domains": list(all_domains),
        }
        return result
    except Exception as e:
        raise ValueError(f"Error preparing response: {e}")
