from bs4 import BeautifulSoup
from typing import List
import logging
import re

# Configure logging
logger = logging.getLogger(__name__)

def strip_html_tags(text: str) -> str:
    """
    Strips all HTML tags from a given text string.

    Parameters:
    text (str): The HTML content as a string.

    Returns:
    str: A plain text string with all HTML tags removed.
    """
    return BeautifulSoup(text, "html.parser").get_text()

def clean_excessive_newlines(text):
    # Replace multiple consecutive newlines (2 or more) with a single newline
    cleaned_text = re.sub(r'\n{2,}', '\n', text)
    return cleaned_text


