import logging
from jinja2 import Template
import re
from pdfminer.high_level import extract_text
from io import BytesIO

def create_html(json_data):

    # Define HTML structure using the provided CSS
    html_template = '''
    <html>
    <head>
        <style>
            body {
                font-family: Aptos, sans-serif;
                line-height: 1.6;
                background-color: #f9f9f9;
                color: #333;
                margin: 20px;
            }
            h2 {
                color: #4CAF50;
                border-bottom: 2px solid #4CAF50;
                padding-bottom: 5px;
            }
            p {
                font-size: 1em;
            }
            ul {
                list-style-type: none;
                padding-left: 0;
            }
            ul li {
                background: #e7f3fe;
                padding: 10px;
                margin: 5px 0;
                border-left: 5px solid #2196F3;
                border-radius: 4px;
            }
            table {
                width: 100%;
                border-collapse: collapse;
                margin-bottom: 20px;
                box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
                background-color: #fff;
            }
            th, td {
                border: 1px solid #ddd;
                padding: 12px;
            }
            th {
                background-color: #4CAF50;
                color: white;
                text-align: left;
            }
            td {
                text-align: center;
            }
            .section {
                margin-bottom: 30px;
                padding: 15px;
                background-color: #ffffff;
                border-radius: 8px;
                box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            }
        </style>
    </head>
    <body>
        {% set section_order = ['FinalEvaluation', 'EmailBodyAnalysis', 'AttachmentReview', 'DomainEvaluation', 'URLEvaluation'] %}
        {% for section in section_order %}
            {% for item in json_data %}
                {% if section in item %}
                    {% set value = item[section] %}
                    {% if section == 'FinalEvaluation' %}
                    <div class='section'>
                        <h2>Final Evaluation</h2>
                        <p><strong>Classification:</strong> 
                            <span style="
                                {% if value.Classification == 'PHISHING' %}
                                    background-color: #d9534f;
                                {% elif value.Classification == 'SUSPICIOUS' %}
                                    background-color: #f0ad4e;
                                {% elif value.Classification == 'BENIGN' %}
                                    background-color: #5bc0de;
                                {% else %}
                                    background-color: #cccccc; /* Default color */
                                {% endif %}
                                color: white; padding: 5px 10px; border-radius: 3px; display: inline-block;">
                                {{ value.Classification }}
                            </span>
                        </p>
                        <p><strong>Confidence Level:</strong> 
                            <span style="
                                {% if value.ConfidenceLevel == 'High' %}
                                    background-color: #0033cc;
                                {% elif value.ConfidenceLevel == 'Medium' %}
                                    background-color: #4d79ff;
                                {% elif value.ConfidenceLevel == 'Low' %}
                                    background-color: #b3c6ff;
                                {% else %}
                                    background-color: #cccccc; /* Default color */
                                {% endif %}
                                color: white; padding: 5px 10px; border-radius: 3px; display: inline-block;">
                                {{ value.ConfidenceLevel }}
                            </span>
                        </p>
                        <p><strong>🔍 Overall Assessment Summary:</strong> {{ value.OverallAssessmentSummary }}</p>
                    </div>
                    {% elif section == 'EmailBodyAnalysis' %}
                    <div class='section'>
                        <h2>Email Body Analysis</h2>
                        <p><strong>✉️ Email Purpose Summary:</strong> {{ value.EmailPurposeSummary }}</p>
                        <p><strong>Intent Summary:</strong> {{ value.IntentSummary }}</p>

                        <h3>Phishing Indicators:</h3>
                        <ul>
                            {% for indicator in value.PhishingIndicators %}
                            <li>⚠️ {{ indicator }}</li>
                            {% endfor %}
                        </ul>
                        {% if value.PositiveIndicators is defined %}
                        <h3>Positive Indicators:</h3>
                        <ul>
                            {% for indicator in value.PositiveIndicators %}
                            <li>✔️ {{ indicator }}</li>
                            {% endfor %}
                        </ul>
                        {% endif %}
                        <p><strong>Overall Phishing Likelihood:</strong> 
                            <span style="
                                {% if value.OverallPhishingLikelihood == 'High' %}
                                    background-color: #4d79ff;
                                {% elif value.OverallPhishingLikelihood == 'Medium' %}
                                    background-color: #4d79ff;
                                {% elif value.OverallPhishingLikelihood == 'Low' %}
                                    background-color: #b3c6ff;
                                {% else %}
                                    background-color: #cccccc; /* Default color */
                                {% endif %}
                                color: white; padding: 5px 10px; border-radius: 3px; display: inline-block;">
                                {{ value.OverallPhishingLikelihood }}
                            </span>
                        </p>
                    </div>
                    {% elif section == 'AttachmentReview' %}
                    <div class='section'>
                        <h2>Attachment Review</h2>
                        <p><strong>📎 Findings:</strong> {{ value.Findings }}</p>
                        <p><strong>Legitimacy Check:</strong> {{ value.LegitimacyCheck }}</p>
                    </div>
                    {% elif section == 'DomainEvaluation' %}
                    <div class='section'>
                        <h2>Domain Evaluation</h2>
                        <p><strong>Overall Domain Assessment:</strong> {{ value.OverallDomainAssessment }}</p>
                        <h3>🌐 Domains Found:</h3>
                        <table>
                            <tr>
                                <th>Domain</th>
                                <th>Reputation</th>
                                <th>Aligned With Email Intent</th>
                            </tr>
                            {% for domain in value.DomainsFound %}
                            <tr>
                                <td>{{ domain.Domain }}</td>
                                <td>{{ domain.Reputation }}</td>
                                <td>{{ domain.AlignedWithEmailIntent }}</td>
                            </tr>
                            {% endfor %}
                        </table>
                    </div>
                    {% elif section == 'URLEvaluation' %}
                    <div class='section'>
                        <h2>URL Evaluation</h2>
                        <p><strong>Overall URL Assessment:</strong> {{ value.OverallUrlAssessment }}</p>
                        <h3>🔗 URLs Found:</h3>
                        <table>
                            <tr>
                                <th>URL</th>
                                <th>Reputation</th>
                                <th>Aligned With Email Intent</th>
                                <th>Redirections</th>
                            </tr>
                            {% for url in value.URLsFound %}
                            <tr>
                                <td>{{ url.URL }}</td>
                                <td>{{ url.Reputation }}</td>
                                <td>{{ url.AlignedWithEmailIntent }}</td>
                                <td>{{ url.Redirections }}</td>
                            </tr>
                            {% endfor %}
                        </table>
                    </div>
                    {% endif %}
                {% endif %}
            {% endfor %}
        {% endfor %}
    </body>
    </html>
    '''
    # Use Jinja2 Template to render HTML with provided JSON data
    template = Template(html_template)
    rendered_html = template.render(json_data=json_data)

    return rendered_html

def extract_and_clean_pdf_text(pdf_bytes):
    """
    Extracts text from a PDF bytes object and performs basic cleanup.
    :param pdf_bytes: PDF file content in bytes
    :return: Extracted and cleaned text from the PDF
    """
    pdf_file_like = BytesIO(pdf_bytes)

    # Extract text from the PDF using pdfminer
    try:
        logging.info("Extracting text from PDF.")
        extracted_text = extract_text(pdf_file_like)
        logging.debug(f"Extracted text length: {len(extracted_text)} characters.")
    except Exception as e:
        logging.error(f"Failed to extract text from PDF: {str(e)}")
        raise

    # Clean up the extracted text
    logging.info("Cleaning up extracted text.")
    try:
        # Remove any non-printable characters and excessive whitespace
        cleaned_text = re.sub(r'[^\x20-\x7E\n\r]+', '', extracted_text)  # Remove non-printable characters
        cleaned_text = re.sub(r'\s+', ' ', cleaned_text).strip()  # Replace multiple whitespaces/newlines with a single space
        logging.debug(f"Cleaned text length: {len(cleaned_text)} characters.")
    except Exception as e:
        logging.error(f"Failed during text cleanup: {str(e)}")
        raise

    return cleaned_text
