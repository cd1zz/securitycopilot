import re
from typing import List, Set, Dict
import urllib.parse
import tldextract
import logging
import requests
import ipaddress
from utilities.text_utils import strip_html_tags

# Configure logging
logger = logging.getLogger(__name__)

# Regex for URL pattern
URL_PATTERN = r'\bhttps?://[a-zA-Z0-9\-._~:/?#[\]@!$&\'()*+,;=%]+\b'
DOMAIN_PATTERN = r'\b[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}\b'
IP_PATTERN = r'\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b'

# String found in all MSFT safelinks urls
SAFELINKS_SUB_DOMAIN = "safelinks.protection.outlook.com"

# List of known URL shortener domains
URL_SHORTENER_PROVIDERS = [
    "bit.ly",
    "t.co",
    "goo.gl",
    "ow.ly",
    "tinyurl.com",
    "is.gd",
    "buff.ly",
    "rebrandly.com",
    "cutt.ly",
    "bl.ink",
    "snip.ly",
    "su.pr",
    "lnkd.in",
    "fb.me",
    "cli.gs",
    "sh.st",
    "mcaf.ee",
    "yourls.org",
    "v.gd",
    "s.id",
    "t.ly",
    "tiny.cc",
    "qlink.me",
    "po.st",
    "short.io",
    "shorturl.at"
]


def extract_domains(content: str) -> Set[str]:
    """
    Extracts domain names from the given string content.

    Parameters:
        content (str): The input string to process.

    Returns:
        Set[str]: A set of extracted domain names.
    """
    logger.info("Extracting domains from content.")
    try:
        # Extract domains from URLs
        urls = re.findall(URL_PATTERN, content)
        domains_from_urls = {tldextract.extract(url).fqdn for url in urls if url}

        # Extract standalone domains
        domains = re.findall(DOMAIN_PATTERN, content)
        standalone_domains = {tldextract.extract(domain).fqdn for domain in domains if domain}

        # Combine all domains
        combined_domains = domains_from_urls.union(standalone_domains)
        return {domain for domain in combined_domains if domain and '.' in domain}
    except Exception as e:
        logger.error(f"Error extracting domains: {e}")
        return set()

def parse_ip_and_urls(content: str) -> Dict[str, List[str]]:
    """
    Parses IP addresses and URLs from the given content.

    Parameters:
        content (str): The input string to process.

    Returns:
        Dict[str, List[str]]: A dictionary containing lists of extracted IP addresses and URLs.
    """
    logger.info("Parsing IP addresses and URLs.")
    try:
        # Extract URLs
        urls = re.findall(URL_PATTERN, content)

        # Decode URLs and clean
        decoded_urls = [urllib.parse.unquote(url) for url in urls]

        # Extract IP addresses
        ip_pattern = r'\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b'
        ip_addresses = re.findall(ip_pattern, content)

        return {
            "urls": list(set(decoded_urls)),
            "ip_addresses": list(set(ip_addresses))
        }
    except Exception as e:
        logger.error(f"Error parsing IPs and URLs: {e}")
        return {"urls": [], "ip_addresses": []}



def expand_url(url: str) -> str:
    """
    Attempts to expand a shortened URL by following redirects.
    If the final connection cannot be made, returns the last known location.

    Parameters:
    url (str): The URL to be expanded.

    Returns:
    str: The expanded URL, or the last known URL if connection fails.
    """
    logger.info(f"Attempting to expand shortened URL: {url}")

    try:
        # Use the GET request here to capture redirections properly and store them
        session = requests.Session()
        response = session.head(url, allow_redirects=True, timeout=5)

        # Capture the final URL
        expanded_url = response.url
        logger.info(f"Successfully expanded URL: {expanded_url}")
        return expanded_url
    except requests.RequestException as e:
        logger.error(f"Connection error expanding shortened URL {url}: {e}")

        # Use history from the session object to retrieve the last valid redirection point
        if hasattr(e, 'response') and e.response is not None:
            logger.info(f"Returning last known redirect URL from history: {e.response.url}")
            return e.response.url
        
        if hasattr(e, 'request'):
            last_redirected_url = e.request.url
            logger.info(f"Returning last known redirected URL from request: {last_redirected_url}")
            return last_redirected_url

        # Attempt HTTP if HTTPS failed
        if url.startswith("https://"):
            fallback_url = url.replace("https://", "http://", 1)
            logger.info(f"Retrying with HTTP: {fallback_url}")
            try:
                response = session.head(fallback_url, allow_redirects=True, timeout=5)
                expanded_url = response.url
                logger.info(f"Successfully expanded URL with HTTP: {expanded_url}")
                return expanded_url
            except requests.RequestException as e:
                logger.error(f"Failed to expand with HTTP fallback: {e}")

                # Attempt to return the last successful redirection URL if available
                if hasattr(e, 'request'):
                    last_redirected_url = e.request.url
                    logger.info(f"Returning last known redirected URL from HTTP fallback: {last_redirected_url}")
                    return last_redirected_url

    # Return the original URL if we couldn't expand it at all
    logger.info(f"Returning original URL, as no expansion could be made: {url}")
    return url


def decode_safelink_url(safelink: str) -> str:
    """
    Decodes a Microsoft SafeLink URL to retrieve the original URL.

    Parameters:
    safelink (str): The SafeLink URL to be decoded.

    Returns:
    str: The decoded original URL, or the original SafeLink if decoding fails.
    """
    logger.info(f"Attempting to decode SafeLink URL: {safelink}")
    try:
        parsed_url = urllib.parse.urlparse(safelink)
        query_params = urllib.parse.parse_qs(parsed_url.query)
        original_url = query_params.get('url', [None])[0]

        if original_url:
            decoded_url = urllib.parse.unquote(original_url)
            logger.info(f"Successfully decoded SafeLink URL to: {decoded_url}")
            return decoded_url
        else:
            logger.info("SafeLink URL could not be decoded, returning original.")
            return safelink  # Return the original SafeLink if 'url' parameter is missing
    except Exception as e:
        logger.error(f"Error decoding SafeLink URL {safelink}: {e}")
        return safelink # Return the original SafeLink if 'url' parameter is missing



def extract_ips(text: str):
    # A simple regex to match potential IP addresses (IPv4 and IPv6 candidates)
    potential_ips = re.findall(r'\b[a-fA-F0-9:.]+\b', text)
    
    ipv4_addresses = []
    ipv6_addresses = []

    for ip in potential_ips:
        try:
            ip_obj = ipaddress.ip_address(ip)
            if ip_obj.version == 4:
                ipv4_addresses.append(ip)
            elif ip_obj.version == 6:
                ipv6_addresses.append(ip)
        except ValueError:
            # Ignore if not a valid IP address
            continue

    return ipv4_addresses, ipv6_addresses

def is_public_ip(ip: str) -> bool:
    """
    Determines if the given IP address is a public IP address.

    Parameters:
    ip (str): The IP address as a string.

    Returns:
    bool: True if the IP address is public, False otherwise (including private, reserved, multicast, loopback, link-local, unspecified, or invalid IP addresses).
    """
    try:
        ip_obj = ipaddress.ip_address(ip)
        return not (ip_obj.is_private or ip_obj.is_multicast or ip_obj.is_reserved or ip_obj.is_loopback or ip_obj.is_link_local or ip_obj.is_unspecified or ip == '255.255.255.255')
    except ValueError:
        return False

def is_image_url(url: str) -> bool:
    """
    Determines if a given URL points to an image file based on its extension.

    Parameters:
    url (str): The URL to be checked.

    Returns:
    bool: True if the URL points to an image, False otherwise.
    """
    image_extensions = ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.svg', '.webp', '.tiff']
    parsed_url = urllib.parse.urlparse(url)
    return any(parsed_url.path.lower().endswith(ext) for ext in image_extensions)

def dedupe_to_base_urls(urls):
    """
    Deduplicates URLs by extracting and keeping only the unique base parts in the form 'http(s)://subdomain.domain.tld'.

    Parameters:
    urls (List[str]): List of URLs to deduplicate.

    Returns:
    List[str]: List of unique base URLs.
    """
    unique_bases = set()
    for url in urls:
        parsed_url = urllib.parse.urlparse(url)
        base_url = f"{parsed_url.scheme}://{parsed_url.netloc}"
        if base_url not in unique_bases:
            unique_bases.add(base_url)
            logger.info(f"Adding unique base URL: {base_url}")
        else:
            logger.info(f"Duplicate base URL skipped: {base_url}")
    
    return list(unique_bases)


def clean_urls(urls: List[str]) -> List[str]:
    """
    Cleans the provided URLs by removing unwanted trailing characters and HTML tags.

    Parameters:
    urls (List[str]): A list of URLs to be cleaned.

    Returns:
    List[str]: A list of cleaned URLs.
    """
    cleaned_urls = []
    for url in urls:
        try:
            # Remove any HTML tags using the strip_html_tags function
            url = strip_html_tags(url)

            # Ensure only the URL part is retained (cut off any extraneous words)
            match = re.match(URL_PATTERN, url)
            if match:
                cleaned_urls.append(match.group(0))
            else:
                logger.info(f"Regex did not match URL {url}")
        except re.error as e:
            logger.error(f"Regex error cleaning URL {url}: {e}")
        except Exception as e:
            logger.error(f"General error cleaning URL {url}: {e}")
    
    return cleaned_urls

def clean_domains(domains: set) -> set:
    """
    Removes leading '2f' or '40' (case-insensitive) from each domain in the provided set.

    Parameters:
    domains (set): A set of domain strings to be cleaned.

    Returns:
    set: A set of cleaned domains with no leading '2f' or '40'.
    """
    cleaned_domains = set()
    for domain in domains:
        # Remove leading '2f' or '40' (case-insensitive)
        cleaned_domain = re.sub(r'^(?i:2f|40)', '', domain)
        cleaned_domains.add(cleaned_domain)
    return cleaned_domains