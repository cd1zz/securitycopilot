import logging
import hashlib
from typing import Union, Dict, List, Set, Tuple
from email import policy
from email.parser import BytesParser
from email.message import EmailMessage
from utilities.entity_utils import extract_ips, is_public_ip, extract_domains, parse_ip_and_urls

logger = logging.getLogger(__name__)

def extract_original_email(raw_email: bytes) -> str:
    """
    Extracts the original email from a raw email byte string, particularly if it's an attachment.

    Parameters:
    raw_email (bytes): The raw email content in bytes.

    Returns:
    str: The original email as a string or the provided raw email if extraction fails.
    """
    try:
        msg = BytesParser(policy=policy.default).parsebytes(raw_email)
    except Exception as e:
        logger.error(f"Error parsing raw email: {e}")
        return raw_email.decode('utf-8', errors='ignore')

    original_email = None
    found_rfc822 = False

    # Extract email parts
    try:
        for part in msg.walk():
            content_type = part.get_content_type()
            main_content_type = part.get_content_maintype()
            content_disposition = part.get("Content-Disposition", None)

            if main_content_type == 'multipart':
                continue
            elif content_type == "message/rfc822" and "attachment" in content_disposition:
                found_rfc822 = True
                logger.info("Raw MSG extracted.")
                original_email = part.get_payload(0)
    except Exception as e:
        logger.error(f"Error while extracting original email content: {e}")
        return raw_email.decode('utf-8', errors='ignore')

    if found_rfc822 and original_email:
        return original_email.as_string()
    else:
        logger.info("No MSG attachment found.")
        return raw_email.decode('utf-8', errors='ignore')

def parse_email(raw_email: bytes) -> Dict:
    try:
        msg = BytesParser(policy=policy.default).parsebytes(raw_email)

        # Extract basic metadata
        sender = msg.get('From', '') or ""
        return_path = msg.get('Return-Path', '') or ""
        email_to = msg.get('To', '') or ""
        subject = msg.get('Subject', '') or ""
        reply_to = msg.get('Reply-To', '') or ""
        date = msg.get('Date', '') or ""
        body = get_body(msg)

        # Extract forwarded message if present
        forwarded_body = extract_forwarded_message(body)
        if forwarded_body:
            logger.info("Forwarded message found and extracted")
            body = forwarded_body

        # Extract authentication results
        dkim_result = parse_authentication_results(msg.get_all('ARC-Authentication-Results', []), "dkim=")
        if dkim_result == "none":
            dkim_result = parse_authentication_results(msg.get_all('Authentication-Results', []), "dkim=")

        spf_result = parse_spf(msg.get_all('Received-SPF', []))
        if spf_result == "none":
            spf_result = parse_authentication_results(msg.get_all('Authentication-Results', []), "spf=")

        dmarc_result = parse_authentication_results(msg.get_all('ARC-Authentication-Results', []), "dmarc=")
        if dmarc_result == "none":
            dmarc_result = parse_authentication_results(msg.get_all('Authentication-Results', []), "dmarc=")

        # Extract IP addresses from Received headers
        received_headers = msg.get_all('Received', []) or []
        header_ips = []
        for header in received_headers:
            header_ips.extend(extract_ips(header))
        header_ips = [ip for ip in header_ips if is_public_ip(ip)]

        # Extract attachments
        attachments = get_attachments(msg)

        # Combine all fields into email_data
        email_data = {
            "date": date,
            "sender": sender,
            "return_path": return_path,
            "delivered_to": msg.get('Delivered-To', '') or "",
            "email_to": email_to,
            "reply_to": reply_to,
            "subject": subject,
            "attachments": attachments,
            "email_body": body,
            "dkim_result": dkim_result,
            "spf_result": spf_result,
            "dmarc_result": dmarc_result,
            "email_headers": received_headers,
            "header_ips": header_ips,  # Include extracted IPs as a separate field
        }

        return email_data

    except Exception as e:
        logger.error(f"Error parsing email: {str(e)}")
        return None


def extract_forwarded_message(body: str) -> str:
    """
    Extracts the content of a forwarded message from the email body if a forwarding keyword is present.

    Parameters:
    body (str): The body content of the email as a string.

    Returns:
    str: The forwarded message content if found, or None if no forwarding indicator is present.
    """
    logger.info("Checking for forwarded message in body")
    split_keywords = ["---------- Forwarded message ---------", "-----Original Message-----"]
    for keyword in split_keywords:
        if keyword in body:
            parts = body.split(keyword, 1)
            logger.info("Forwarded message keyword found, extracting forwarded content")
            forwarded_content = parts[1].strip()
            forwarded_body = "\n".join(forwarded_content.split('\n')[4:]).strip()
            return forwarded_body
    logger.info("No forwarded message keyword found in body")
    return None

def get_body(email_message: EmailMessage) -> str:
    """
    Extracts the body content from an email message, handling both multipart and non-multipart emails.

    Parameters:
    email_message (EmailMessage): The email message object to extract the body from.

    Returns:
    str: The extracted body content of the email as a string. If the email is multipart,
         the function joins all relevant parts, otherwise it returns the decoded payload.
    """
    if email_message.is_multipart():
        logger.info("Email is multipart, iterating over parts")
        parts = [
            get_body(part).strip()
            for part in email_message.iter_parts()
            if part.is_multipart() or part.get_content_type() in ['text/plain', 'text/html']
        ]
        return "\n".join(part for part in parts if part)
    else:
        logger.info("Email is not multipart, extracting payload directly")
        payload = email_message.get_payload(decode=True)
        charset = email_message.get_content_charset() or 'utf-8'
        return payload.decode(charset).strip() if payload else ""


def get_attachments(email_message: EmailMessage) -> List[Dict[str, str]]:
    """
    Retrieves the attachments from an email, calculates their SHA-256 hash, 
    and extracts the attachment as a base64-encoded string along with content type.

    Parameters:
    email_message (EmailMessage): The email message object.

    Returns:
    List[Dict[str, str]]: A list of dictionaries containing attachment names, 
                          their SHA-256 hash values, base64-encoded content, and content type.
    """
    attachments = []
    logger.info("Starting to extract attachments from email.")

    for part in email_message.iter_attachments():
        try:
            logger.info(f"Processing attachment: {part.get_filename()}")

            if part.get_filename():
                # Get the base64 string of the file (without decoding to raw bytes)
                file_base64 = part.get_payload(decode=False)
                logger.info(f"Retrieved base64 string for attachment: {part.get_filename()}")

                # Decode base64 to bytes for SHA-256 hash calculation
                file_bytes = part.get_payload(decode=True)
                sha256_hash = hashlib.sha256(file_bytes).hexdigest()
                logger.info(f"Calculated SHA-256 hash for attachment '{part.get_filename()}': {sha256_hash}")

                # Get content type
                content_type = part.get_content_type()
                logger.info(f"Content type for attachment '{part.get_filename()}': {content_type}")

                attachment_data = {
                    'attachment_name': part.get_filename(),
                    'attachment_sha256': sha256_hash,
                    'attachment_base64': file_base64,
                    'content_type': content_type
                }

                attachments.append(attachment_data)
                logger.info(f"Attachment '{part.get_filename()}' processed and added to list.")
        except Exception as e:
            logger.error(f"Error processing attachment '{part.get_filename()}': {e}")

    logger.info("Finished extracting attachments from email.")
    return attachments

def parse_authentication_results(headers, keyword):
    """
    Parses email headers to extract authentication results based on a specific keyword.

    Parameters:
    headers (List[str]): A list of email header strings to be parsed.
    keyword (str): The keyword to search for in the authentication results (e.g., "dkim=", "spf=", "dmarc=").

    Returns:
    str: A string containing the matching authentication results separated by semicolons, or "none" if no matches are found.
    """
    results = []
    for header in headers:
        parts = header.split(";")
        for part in parts:
            if keyword in part:
                results.append(part.strip())
    return "; ".join(results) if results else "none"


def parse_spf(headers):
    """
    Parses email headers to extract SPF (Sender Policy Framework) results.

    Parameters:
    headers (List[str]): A list of email header strings to be parsed.

    Returns:
    str: A string containing the SPF results separated by semicolons, or "none" if no SPF results are found.
    """
    results = []
    for header in headers:
        if header.startswith("Received-SPF"):
            results.append(header.strip())
    return "; ".join(results) if results else "none"



def recursive_parse(content: Union[Dict, List, str]) -> Tuple[Set[str], Set[str], Set[str]]:
    """
    Recursively parses email content to extract domains, IP addresses, and URLs.
    """
    extracted_domains, extracted_ips, extracted_urls = set(), set(), set()

    def parse_item(item):
        nonlocal extracted_domains, extracted_ips, extracted_urls
        if isinstance(item, dict):
            for value in item.values():
                parse_item(value)
        elif isinstance(item, list):
            for value in item:
                parse_item(value)
        elif isinstance(item, str):
            try:
                extracted_domains.update(extract_domains(item))
                parsed_data = parse_ip_and_urls(item)
                extracted_ips.update(parsed_data['ip_addresses'])
                extracted_urls.update(parsed_data['urls'])
            except Exception as e:
                logger.error(f"Error parsing string content: {e}")

    parse_item(content)
    return extracted_domains, extracted_ips, extracted_urls
